# version 0.1-3

* add `st_geod_covered_by` binary geometry predicate

# version 0.1-2

* try to fix OSX compile on CRAN, tuning configure.ac

# version 0.1-1

* add `st_length`

* attempt to fix Solaris and OSX

* report proj.4 and GEOS versions on startup, and on `lwgeom_extSoftwareVersions`; #10

* add minimum bounding circle, by @rundel; #7

* add `st_subdivide`, see https://github.com/r-spatial/sf/issues/597

# version 0.1-0

* first CRAN submission
